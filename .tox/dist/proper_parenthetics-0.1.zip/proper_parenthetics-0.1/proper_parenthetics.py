# _*_ utf-8 _*_
"""Interview Challenge: Proper Parenthetics."""
from collections import Counter
    # splits = Counter(string)
    # lst = []
    # for i in string:
    #     if i == ")" or i == "(":
    #         lst.append(i)
    # print("Parenthetics in order: " + str(lst))
    # if splits["("] == splits[")"]:
    #     for i in string:

    # print(splits)


def parens(string):
    """Check a string to make sure correct number of parenthesis are there."""
    paren_dict = Counter(string)

    # count = 0
    # for idx in string:
    #     if idx is u"(":
    #         count += 1
    #     elif idx is u")":
    #         count -= 1

    if paren_dict[")"] < paren_dict["("]:
        print("OPEN " + str(paren_dict["("]))
        print("CLOSED " + str(paren_dict[")"]))
        print(1)
        return 1

    elif paren_dict[")"] > paren_dict["("]:
        print("OPEN " + str(paren_dict["("]))
        print("CLOSED " + str(paren_dict[")"]))
        print(-1)
        return (-1)

    else:
        if all([paren_dict[")"] == paren_dict["("],
                string.find(")") > string.find("("),
                string.rfind(")") > string.rfind("(")]):
            print(0)
            return 0
        else:
            print(-1)
            return (-1)


# un-comment the lines below to allow user input on command line
if __name__ == '__main__':
    string = input(u'Input string here: \n')
    parens(string)
